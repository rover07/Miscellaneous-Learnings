# Relationship

# Dusro ke Pass hai Tumare pass nhi hai?

1. Tumare pass abhi koi data nhi hai unke bare me jo hai vo unone  hi diya hai ushi data ke basis me tum soch rahe ko kass mere pass bhi hoti to mai bhi aise khush rahta, kyu ki unone tume sirf khusi vala data diya hai.

1. So agar ye sab soch ke tum relationship me aaoge to higly chance hai ki tumari life ki watt lag jayegi because fhir tume vo pata cahlega ki kitna tension hota hai, so just relax agar abhi nhi hai

1. Abhi khud pe dhyaan do later on tume bahut option milenge choose karneke.

# Tumare Pass hai, lekin Roj ladaiya hoti hai tum ja nhi pate, jana to chate ho chood ke

1. Tum aise relationship me ayee hi kyu?, it’s mean tum bas ghus gye tume kuch nhi pata tha ki inssan kaisa hai ye, ab tume uske bare me pata chala hai tabhi ladaiya hoti hai?

1. Roj Roj ke ladayi se tumara mental or physical dono level me drain hota hai.

1. Tume isse nikana hoga, it’s hard but you have to do, no second chance no break just come out from such toxic relation.

1. Annge bahut logf milenge so ye mat socho ab agar gaya to koi nhi milega.

1. Usse msg karo ya call karo or sab confess kardo ki tum jana chata ho or reason batao ki tume kuch nhi pata tha ab jake bahut ladaiye ho rahi.

1. Ek baar nikal jaao to dubara mat jana uske pass bas ye samjo ek partner mila tha but uske sath tumari bani nhi, koi jarurat nhi block karne ki na use hate dene ki just move from it. 

# Tumne Propose kiya lekin usne friend-Zone Kar diya, ya reject kar diya

1. Tumne usee propose kiya, why aisa kya dikha?, jo tume laga usko mujhe as a partner consider karna hai, kya bas khali jagah bharni hai ya sex chaiye tha fhir chahe koi bhi mil jaye?

1. Agar usne reject kiya hai to bura kyu lag raha hai tume?, proposal ka matlab bhi pata hai?, proposal ka matlab hota hai tumne offer kiya or samne vale ke pass pura haq hai tume reject or accept karne ka.

1. tum kisi ko own nhi karte ho agar kisi ne reject kiya hai to accept karo, or ye mat sochna tum me koi kami hai nhi bahut reason ho sakte hai ki usne reject kyu kiya, so ye mat sochna ki tum ugly ho sundar nhi ho etc.

1. khud me kaam karo bechare met bano ek din aisa ayega log tume offer denge fhir tumare pass choice hogi accept or reject karne ki total

# Usne tume cheat kiya ya kuch bhi hua ho bas tumara breakup ho gaya, or ab tumari halat khrab hai

1. Usne cheat kiya?, tume pata chal gaya bas bahut hai ab koi second chance nhi dena kisi ko, agar uss insaan ne first place me hi cheat kiya hai to matlab vo insaan tumari value nhi karta.

1. Just thank to the god ki tume ye pata chala.

1. Tumne apnma bahut time usko diya hai usko aise nhi bula sakte yaad to ayegi hi.

1. Koi sad song nhi sunna koi photo nhi dekhni use bhagwaan mat banaao koi achhi chezz nhi khoyi tumne,   ek cheater dur kiya hai tumne apni life se ye or achii baat hai.

1. Jab bhi yaad ayee khud se bolo tez tez mai bhi insaan hu vo bhi insaan thi, maine usse bahut hope attached kar li thi ab time lagega mujhe nikalne me lekin nikal jaunga

1. Khud ko daily best banao system follow karo 1% valaa, yaad ayegi uski it’s normal, lekin khud ko barbaad nhi karna hai ab or.

1. or apni galti samjo ki tumne iss insaan ko choose kyu kiya tha ya usne agar propose kiya tha to accept kyu kiya? aisa kya thaa???

# Do You Want Your Ex-Relation back?

1. Ok usko fhir se pana chate ho????, lekin breakup ek vajah se hua tha right??, may be usne cheat kiya ho ya tumari koi galti ho jo bhi.

### If she cheated

1. Agar usne cheat kiya tha to, bhai tu pagal hai kya, matlab indirectly tu bol raha hai ek insaan ne mereko dhoka diya lekin mai itna gira hua hu mai usko dobara chata hu apni life me.

1. Kya guarantee hai vo ye dubaraa nhi karegaa??

1. Or agar vapis mil bhi gaya to din raat tum yahi sochoge ki kahi merepe fhir se cheat na karde, kyu ki tum khud andar se khokhle ho, pahle khud me kaam kar bhai, matlab u are not watchman ki dekhe kaha ja rahi kahi cheat na karde.

1. Jab tu khud successful ho jayega to tume achee log milenge abhi kachre me hai to kachraa hi milega sale, iska matlab ye nhi ki kachraa baar baar udaya tu even vo badboo kar raha fhir bhi.

### Tumari galti thi

1. Tumari galti thi puri??? ya ushe jane ka bhana chaiye tha or tumari galti itni thi bhi nhi badi lekin bhaag gyi vo ye dikha ke ki tumne hi kiya sab???, any way kuch bhi ho.

1. Uss insaan ko sorry bolo and say meri galti ho sake to maaf kar dena, now ab tume ye nhi kahna hai ki vapis aa jaao nhi tume bas apni galti accept karni hai ek insaan hone ke nate.

1. Ab tume samajna hai ki tume kya kami hai kyu tumne cheat kiya ya aisa kya tha jo ye hua agar tume lagta hai ki tumne cheat kiyaa toatally so just say sorry to her, and from now kabhi bhi aisa na karna relation me

1. But ab kare kya ab to tum single ho ab tume khud me kaam karna hai koi ladki nhi dudni jab tak tume na lage ki tum readyy ho.

1. Or stop cheating nhi to karma ayega or achee se maregaa or agar tumari itni badi galti nhi thi fhir bhi vo bhaag gyi so just relax usko baHana chaiye tha bas jane ka or vo chali gyi.

1. Koi sad song nhi sunna koi photo nhi dekhni use bhagwaan mat banaao koi achhi chezz nhi khoyi tumne,   ek cheater dur kiya hai tumne apni life se ye or achii baat hai.

1. Jab bhi yaad ayee khud se bolo tez tez mai bhi insaan hu vo bhi insaan thi, maine usse bahut hope attached kar li thi ab time lagega mujhe nikalne me lekin nikal jaunga

1. Khud ko daily best banao system follow karo 1% valaa, yaad ayegi uski it’s normal, lekin khud ko barbaad nhi karna hai ab or.

# kaise pata kare ki Kisi proposal ko accept karne ka ye sahi time hai ya nhi

1. Kya tum afford kar sakte ho apna time distribute karna ???, agar vo chali jayegi in future to khud ko sambhaal paaoge?? kahi ye time apna career banane ka to nhi ??

1. Agar insaan harami nikla to??? ye sab possibilities bhi to dekho hameesa bollywood vale song kyu chalne lagte hai background me.

1. Kahi tumara adhaa time usko stalk karne me to nhi jayega ki kahi ja to nhi rahi aree ye kon ladka hai inke friend list me, kahi ye kisi or se baat to nhi kar rahi agar ye sab abhi bhi lagta hai hoga relation me anee ke baad it’s mean tume khud pe kaam karna hai tum khud abhi sure nhi ho ki tum kaya ho.

# Achha partner kaise milega usme kya quality dekhe?

1. Ek achaa partner tumare hisaab se kaisa hona chaiye write down your demand.
2. Vo insaan ke pass sex ke alawa kya dene ko tume??

1. Aisa insaan dudoo jiske sath pura din nikal do fhir bhi baat rah hi jaye karne ko, tume soch ke na bolna pade ki ye bolu ya nhi kahi bura na maan jayee.

1. Try to marry if you get such partner.
2. Kya vo career me dyaan deta hai ya nhi??
3. Uske thoughts kitne match hote hai tumse?? matlab agar tum 10 bate bolte ho to vo kitne me agreee karta hai or tum uski 10 batoo me se kitne me agree karte ho.
4. Future ke baree me kya sochti hai kahi bas husband ke paise me aiss to nhi karne ka socthii??