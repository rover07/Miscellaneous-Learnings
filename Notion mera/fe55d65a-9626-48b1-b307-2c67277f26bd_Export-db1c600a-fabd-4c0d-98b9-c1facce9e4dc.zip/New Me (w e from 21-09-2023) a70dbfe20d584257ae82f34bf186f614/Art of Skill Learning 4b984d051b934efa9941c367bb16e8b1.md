# Art of Skill Learning

*the devil wouldn't attacking you so hard if there wasn't something valuable inside of you, remember thieves don't break into empty home. —- someone*

- Frontend Development

# Base of my Field

[Computer Base & Hardware](Art%20of%20Skill%20Learning%204b984d051b934efa9941c367bb16e8b1/Computer%20Base%20&%20Hardware%209dbb9f931c594564a69591c9b2dd565f.md)

[**Operating System**](Art%20of%20Skill%20Learning%204b984d051b934efa9941c367bb16e8b1/Operating%20System%20413482cdc46b4c89b23586b80fcc13dc.md)

[**Networking**](Art%20of%20Skill%20Learning%204b984d051b934efa9941c367bb16e8b1/Networking%20ae82974675fc4269a50f21e1ea12eece.md)

[**Data-Structure &** **Algorithms**](Art%20of%20Skill%20Learning%204b984d051b934efa9941c367bb16e8b1/Data-Structure%20&%20Algorithms%20fdb2dd6869704081a9eebba4f95364aa.md)

# Skills of my field

[HTML](Art%20of%20Skill%20Learning%204b984d051b934efa9941c367bb16e8b1/HTML%20625d2f8edc59451cacfb8770c03692d3.md)

[CSS](Art%20of%20Skill%20Learning%204b984d051b934efa9941c367bb16e8b1/CSS%20c6d082543e454b27ad1972bac39b5eab.md)