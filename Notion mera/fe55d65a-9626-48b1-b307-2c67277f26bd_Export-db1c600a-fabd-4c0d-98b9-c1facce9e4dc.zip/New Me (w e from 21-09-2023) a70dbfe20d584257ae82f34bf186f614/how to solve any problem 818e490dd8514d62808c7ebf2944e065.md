# how to solve any problem

---

1. **Write your problem here. (Kya tumare contol me hai kya isse solve ya thoda control kar sakte ho).**

Timepass and p0rn

1. **What is the trigger that makes me do this?**

watching a lot of videos on the internet, basically youtube

1. **IS THIS A PATTERN THAT I DO DAILY?**

Yes 

1. **What do I need to change to avoid the trigger?**

Replace YouTube watching and mindless scrolling with Work

1. **How does that fuck me up in the long term?**

Takes up most of the time and focus.

## Iss problem ko Yaha Pel Do

Replace that’s it.

---

---