# Self-Help

**Articles**

- [https://www.reddit.com/r/learnprogramming/comments/4pgb44/im_afraid_if_i_say_anything_on_github_people_will/](https://www.reddit.com/r/learnprogramming/comments/4pgb44/im_afraid_if_i_say_anything_on_github_people_will/)
- [https://www.saintlymonkey.com/2019/03/is-lack-of-focus-disease-or-choice.html?m=1](https://www.saintlymonkey.com/2019/03/is-lack-of-focus-disease-or-choice.html?m=1)
- [https://www.quantamagazine.org/june-huh-high-school-dropout-wins-the-fields-medal-20220705/](https://www.quantamagazine.org/june-huh-high-school-dropout-wins-the-fields-medal-20220705/)
- [https://www.growyouragency.com/iman-gadzhi/](https://www.growyouragency.com/iman-gadzhi/)

[**My Playlist**](https://youtube.com/playlist?list=PL9AedAKNmDw29lG1D-1obOMzSZK6XiO-0&si=DC12FRe3mRPSMUHc)