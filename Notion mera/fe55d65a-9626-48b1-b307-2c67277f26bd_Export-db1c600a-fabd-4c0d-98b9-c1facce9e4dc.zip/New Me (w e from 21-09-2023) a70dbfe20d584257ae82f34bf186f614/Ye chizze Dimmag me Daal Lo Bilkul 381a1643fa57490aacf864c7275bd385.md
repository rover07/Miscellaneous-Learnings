# Ye chizze Dimmag me Daal Lo Bilkul

- Mai past me fail hua tha to vo mai uss chizz me fail hua tha, kyu ki maine uspe kaam nhi kiya tha iska matlab ye nhi mai totally failure hu ya meri limits hai.

- Koi bhi banda jiski knowlege bahut hai mai usee god nhi manuga, Vo bhi mere tarah ek insaan hai jisne mahnat ki hai or uss skill ko time diya hai, mai bhi dunga mai bhi ban jaunga

- Agar mere me knowledge hai ya mai kisi cheez me achaa hu to mai ego nhi launga, mai usse or share karunga

- agar koi inssan english bol raha achii to iska matlab ye nhi uski har baat sach ho or vo bahut educated hai, english bas ek language hai like other jo ki mai bhi achee se sikhunga taki mai office etc me achhe se logo ke beech gul mil saku.

- mere past me jo bhi hua mere sath mujhe ab usse bhulna hoga ek naya chapter start karna hoga, mera past mera past hai ab present or future ko past jaisa nhi banne dunga.

- Tum sirf tum ho tumko koi bachane nhi ayega kyu ki koi bacha hi nhi sakta tume,  tumare parents bhi nhi kuch kar sakte, Ek tum hi ho jo khud ko samjte ho, Koi motivational speaker kaam nhi ayega koi video Kaam nhi ayega, Sirf system hi tume Sudhar sakta hai