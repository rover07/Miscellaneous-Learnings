# Today (Sirf Aaj Karna Hai Bas)

- 1% Mast Physique 💪
- 1% Mast Dimaag 🧠
- 1% Fuck You Money 💵

# Morning ka Aaj Ka

- [ ]  5:00 tak uth jana hai
- [ ]  1 Liter Pani Pelna hai kas ke 💪
- [ ]  Running 2km 💪
- [ ]  2 Aloo and channa 💪
- [ ]  Reading 🧠
- [ ]  Coffee 2 hours after waking up(Monday-Friday)
- [ ]  War ke liye Ready Hona hai(Make a to-do now) 🧠

# Dophar Ka Aaj Ka(12-6pm)

- [ ]  Set 1 (45 min)
- [ ]  Set 2 (45 min)
- [ ]  Set 3 (45 min)
- [ ]  Powernap 30min Kam se kam
- [ ]  Set 4 (45 min)
- [ ]  Set 5 (45 min)
- [ ]  Set 6 (45 min)

# Raat Ka Aaj Ka(6-11pm)

- [ ]  7:30 pe workout. 💪
- [ ]  Kal ka system banana hai
- [ ]  11 baje se pahle so jana hai.