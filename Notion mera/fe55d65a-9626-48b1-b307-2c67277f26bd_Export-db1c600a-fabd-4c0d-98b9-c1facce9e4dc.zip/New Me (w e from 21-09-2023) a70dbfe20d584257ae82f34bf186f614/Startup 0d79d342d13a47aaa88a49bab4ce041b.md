# Startup

# Podcasts

[Playlist](https://youtube.com/playlist?list=PL9AedAKNmDw2H51ZeGGWPxkt-ZWv_gCiM&si=5FnuvUxgwGov0RcZ)

[Y Combinator Playlist](https://youtube.com/playlist?list=PL5q_lef6zVkaTY_cT1k7qFNF2TidHCe-1&si=Fyxv4fqGMqwTWw20)

# Resources+VC’s

[https://free-for.dev/#/?id=apis-data-and-ml](https://free-for.dev/#/?id=apis-data-and-ml)

[https://www.blackbird.vc/get-investment](https://www.blackbird.vc/get-investment)

[https://thielfellowship.org/apply](https://thielfellowship.org/apply)

[https://www.ycombinator.com/apply](https://www.ycombinator.com/apply)

[https://www.f6s.com/](https://www.f6s.com/)

[https://buildspace.so/](https://buildspace.so/)

[https://startup.google.com/](https://startup.google.com/)

[https://github.com/KrishMunot/awesome-startup](https://github.com/KrishMunot/awesome-startup)