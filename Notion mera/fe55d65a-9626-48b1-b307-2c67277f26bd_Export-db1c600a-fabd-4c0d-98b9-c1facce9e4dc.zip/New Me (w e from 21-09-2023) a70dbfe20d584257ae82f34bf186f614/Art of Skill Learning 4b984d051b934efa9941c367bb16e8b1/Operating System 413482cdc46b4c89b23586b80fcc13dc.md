# Operating System

- **What is an Operating System.**
    
    **An operating system (OS) is a software program that acts as an intermediary between computer hardware and the various software applications that run on a computer.**
    
    ![https://www.tutorialspoint.com/operating_system/images/conceptual_view.jpg](https://www.tutorialspoint.com/operating_system/images/conceptual_view.jpg)
    
    1. **Resource Management:** The OS allocates and manages system resources such as memory, CPU time, disk space, and input/output devices. It ensures that multiple applications can run simultaneously without interfering with each other.
    
    1. **Process Management:** The OS controls the execution of software programs, known as processes. It handles process creation, scheduling, synchronization, and termination. This allows multiple programs to run concurrently on a single system.
    
    1. **Memory Management:** The OS oversees the allocation and management of system memory. It keeps track of which parts of memory are in use and which are available, ensuring that different processes and applications do not overwrite each other's data.
    
    1. **File System Management:** The OS provides a hierarchical structure for organizing and storing files on storage devices such as hard drives and solid-state drives. It manages file creation, deletion, reading, and writing operations.
    
    1. **Device Management:** The OS communicates with hardware devices such as printers, displays, keyboards, and network adapters. It provides device drivers that allow software applications to interact with hardware components.
    
    1. **User Interface:** The OS offers a user interface through which users can interact with the computer. This can be a command-line interface (CLI) or a graphical user interface (GUI), providing a way for users to issue commands and manage files and applications.
    
    1. **Security and Access Control:** The OS enforces security measures to protect the system and user data. It controls user access toresources and data, managing authentication and authorization processes.
    
    1. **Error Handling:** The OS monitors the system for errors, both hardware and software-related. It provides error-handling mechanisms to prevent catastrophic failures and ensure the system's stability.
- **Types of Operating System.**
    - **Batch Operating System**
        - **A batch operating system is a type of operating system that manages and executes a series of jobs or tasks in a batch or group without requiring continuous user intervention.**
        
        - **In a batch processing environment, users submit their tasks or programs to the system as a batch, and the operating system then processes these tasks one after another, without requiring constant input from the user.**
        
    - **Multi-Programmed OS**
        - **A multi-programming operating system is a type of operating system that allows multiple programs or processes to be loaded into memory and executed concurrently.**
        - **This concept was developed to increase the utilization of the computer's resources and improve overall system efficiency.**
    - **Multi-Tasking OS**
        - A multitasking operating system is a type of operating system that allows multiple tasks or processes to run concurrently on a single computer system. These tasks can be user applications, system services, or background processes, and they share the CPU's processing time in a way that gives the illusion of simultaneous execution.
    - **Real Time OS**
        - A real-time operating system (RTOS) is a type of operating system designed to meet the requirements of real-time systems, where timely and predictable execution of tasks is essential.
        
        - Real-time systems are used in applications where tasks must be completed within certain time constraints to ensure correct functionality and safety.
        
        - **Hard Real-Time vs. Soft Real-Time:** Real-time systems 
        can be categorized into hard real-time (strict deadlines must be met) 
        and soft real-time (meeting deadlines is desirable but not mandatory).
        
        - Examples of applications that utilize real-time operating systems include industrial control systems, robotics, automotive systems (such as anti-lock braking systems), aerospace systems, medical devices, and multimedia systems.
    - **Distributed OS**
        - A distributed operating system (DOS) is an operating system that runs on multiple interconnected computers and enables them to work together as a single cohesive system.
        - The primary goal of a distributed operating system is to provide a unified environment that abstracts the complexity of distributed computing, allowing users and applications to interact with the networked resources as if they were part of a single computer.
        - node can be placed anywhere in the world
    - **Clustered OS**
        
        Same like distributed system but, we have nodes available physically on same location
        
    - **Embedded OS**
        - An embedded operating system (Embedded OS) is a specialized type of operating system designed to run on embedded systems.
        - Embedded systems are computer systems that are integrated into other devices or products to perform specific functions. These systems are often dedicated to a particular task and may have resource constraints such as limited processing power, memory, and storage.
- **What is a Process**
    - A process is a fundamental concept in operating systems that represents the execution of a program in a computer's central processing unit (CPU).
    - It's a running instance of a program that has its own memory space, program counter, registers, and system resources.
    - Each process is assigned a unique identifier called a Process ID (PID), which is used by the operating system to manage and identify processes.
    - In Unix-like operating systems, processes can be organized into a parent-child hierarchy, where a parent process creates child processes. The child processes inherit certain attributes from their parent.
    - Processes have a lifecycle that includes creation, execution, waiting, and termination. Processes can be in different states, such as running, sleeping, or blocked.
- **Process States (Process lifecycle)**
    - **New:** This is the initial state where the process is being created by the OS. Resources such as memory space and process control blocks (PCBs) are allocated during this state.
    
    - **Ready:** In this state, the process is loaded into the main memory and is waiting to be executed. It has all the necessary resources and is in a position to be scheduled by the CPU.
    
    - **Running:** The process is in this state when the CPU is actively executing its instructions. In a multitasking environment, multiple processes might be in the running state, and the CPU scheduler switches between them.
    
    - **Blocked (Waiting):** Processes in this state are unable to proceed because they are waiting for some external event or resource,such as user input, a file to be read from disk, or completion of I/O operations. The process moves to this state voluntarily (e.g., waiting 
    for user input) or involuntarily (e.g., waiting for an I/O operation to complete).
    
    - **Terminated (Exit):** When a process completes its execution or is explicitly terminated, it enters this state. The OS then reclaims any allocated resources and updates relevant accounting information.
        
        ## Process Life-cycle
        
    1. **New to Ready:** When a new process is created, it transitions to the ready state as the OS prepares it for execution.
    2. **Ready to Running:** The scheduler selects a process from the ready queue and allocates CPU time to it, moving it to the running state.
    3. **Running to Blocked:** A process might transition to the blocked state if it initiates an I/O operation or some other activity that requires waiting for an external event.
    4. **Running to Ready:** A running process might be preempted by the scheduler, causing it to move back to the ready state to allow other processes to execute.(reason - time quantum, other process priority)
    5. **Blocked to Ready:** Once the awaited event or resource becomes available, the process moves from the blocked state to the ready state and waits to be scheduled.
    6. **Running to Terminated:** When a process completes its execution or is terminated for some reason, it moves to the terminated state.
- **Types of Schedulers**
    
    
    **Long-term-Scheduler** **-** The Long-Term Scheduler's primary role is to select processes from the pool of new processes and determine which processes should be admitted to the system for execution.
    
    Its primary goal is to maintain a balance between the number of processes in memory and the overall system load to prevent overloading the system.
    
    **Short-term-Scheduler -**  The Short-Term Scheduler is responsible for selecting the next process from the pool of ready processes and determining which process should run on the CPU.
    
    Its main goal is to provide fair and efficient CPU utilization while considering factors like process priority and time-sharing.
    
    **Medium-term-Scheduler -** The Medium-Term Scheduler acts as an intermediary between the Long-Term Scheduler and the Short-Term Scheduler. It can be found in some operating system designs and is not present in all systems.
    
    The Medium-Term Scheduler aims to control the degree of multi-programming in the system. It manages processes that are in memory but are not actively executing.
    
    This scheduler may decide to suspend or swap out processes from memory to disk when the system becomes heavily loaded or to optimize overall system performance.
    

- **User_Mode & Kernel_Mode**
    
    ![https://cstaleem.com/wp-content/uploads/2020/05/User-Mode-Vs-Kernel-Mode.png](https://cstaleem.com/wp-content/uploads/2020/05/User-Mode-Vs-Kernel-Mode.png)
    
- **System Calls in OS**
    - In an operating system, a system call is a mechanism that allows a user-level program or process to request a service or resource from the kernel, which is the core part of the operating system.
    - System calls provide an interface for user-level programs to interact with the underlying hardware and access functionalities that are typically beyond their direct reach due to the protection mechanisms provided by the operating system.
    
    **Some Important System Calls**
    
    **File Related System Calls -** Open(), Read(), Write(), Close(), lseek(), unlink(), rename()
    
    **Information Based System Calls -**  getpid()/getppid(), gettimeofdelay(), getuid(), gettimeofday()
    
    **Process Control System Calls -** fork(), exec(), wait()/waitpid(), kill(), abort()
    
    **Communication Based System Calls -** pipe(), dup(), shmget()
    
- **Fork() System Call**
    - The `fork()` system call is a fundamental operation for creating new processes in Unix-like operating systems. It's a mechanism through which a new process (child process) is created as a copy of the current process (parent process).
    - The new child process is a duplicate of the parent, and both processes continue executing independently after the `fork()` call.
    - The primary use of `fork()` is to create a new process that performs a related but separate task from the parent process.
    - Often, after a successful `fork()`, one of the processes (usually the child) will execute a different program using one of the `exec()` system calls, replacing its memory space with a new program.
- **Process Vs Thread**
    
    
    | Processes | Threads |
    | --- | --- |
    | Isolation: Processes are isolated from each other. Each process has its own memory space, resources, and system state. One process cannot directly access another process's memory. | Shared Resources: Threads within the same process share the same memory space, which allows them to communicate and share data 
    more easily compared to processes. |
    | Creation Overhead: Creating a new process is relatively more resource-intensive because it involves duplicating the entire process's memory space, code, data, and other resources. | Creation Overhead: Creating a new thread is less resource-intensive than creating a new process since threads share the 
    memory space of the parent process. |
    | Scalability: Processes are heavyweight, which can limit the scalability of a system with a large number of processes. | Scalability: Threads are lightweight compared to processes, which makes them more suitable for applications requiring high levels of concurrency. |
    | Security: Processes inherently provide better security and fault tolerance due to their isolation. A vulnerability in one process is less likely to affect others. | Security: Since threads share the same memory space, a bug in one thread can potentially affect others. However, this is 
    mitigated through proper synchronization mechanisms. |
- **User-level-Thread & Kernel-level-Thread**
    
    
    | User-Level-thread | Kernel-Level-Thread |
    | --- | --- |
    | User-level threads, also known as "green threads," are managed entirely by the application or user-level library rather than the operating system kernel. | Kernel-level threads are managed and scheduled by the operating system kernel. Each kernel-level thread is represented and managed individually by the kernel, allowing the operating system to perform scheduling and context switching at the thread level. |
    | Lightweight: Creating and switching user-level threads is generally faster and requires less overhead compared to kernel-level threads. | Higher Overhead: The management of kernel-level threads requires more overhead due to interactions with the operating system, including system calls for thread creation, synchronization, and scheduling. |
    | Limited Concurrency: Since user-level threads are managed within the application's address space, they may not take full advantage of multi-core processors or other hardware-level concurrency features. | True Concurrency: Kernel-level threads can be scheduled on separate processors or cores, maximizing the utilization of available hardware resources. |
    | Blocked Threads: If one user-level thread within a process blocks (e.g., waits for I/O), all threads in the same process are blocked, as the operating system is unaware of the internal thread state. | Better Responsiveness: Even if one kernel-level thread blocks, the operating system can continue scheduling other threads, ensuring better responsiveness. |

- **Process Scheduling Algorithms( Preemption Vs Non-Preemption )**
    
    
    **Preemption**
    
    - In preemptive scheduling, a running process can be interrupted and moved out of the CPU even before it has completed its execution.
    - The operating system decides when to switch to another process based on priority or a predetermined time slice.
    - This type of scheduling is more dynamic and is generally used in time-sharing or multitasking environments.
    
    **Non-Preemption**
    
    - In non-preemptive scheduling, a running process is not forcibly removed from the CPU until it completes its execution or enters a waiting state.
    - This approach is simpler in terms of context switching but may lead to longer response times for interactive processes and poorer utilization of CPU resources.
- **Concept of Arrival, Burst, Completion, Turnaround, Waiting & Response time.**
    
    
    **Arrival Time -** Arrival time is a concept in process scheduling that refers to the point in time when a process enters the system and becomes ready for execution.(A time not duration)
    
    **Burst -** a burst refers to a period of time during which a process executes on the CPU without being interrupted.(Duration)
    
    **Completion -** the time at which process Complete it’s execution.(A time not duration)
    
    **Turn Around time -** {Completion time - Arrival time}
    
    **Waiting Time -** {Turn Around time - Burst Time}
    
    **Response Time -** { (the point of time, the process get cpu) - (Arrival Time) }
    
- **FIrst-Come, First-Serve algorithm(FCFS)**
    
    
    - The simplest scheduling algorithm.
    - Processes are executed in the order they arrive in the ready queue.
    - Non-preemptive: Once a process starts executing, it continues until it completes or enters a waiting state.
    
- **Shortest Job Next (SJN) / Shortest Job First (SJF) Scheduling**
    
    
    - Processes are executed in ascending order of their burst times.
    - Preemptive version: A process with a shorter remaining burst time can preempt the currently running process.
    - Non-preemptive version: The next process starts only after the current one completes.