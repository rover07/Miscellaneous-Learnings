# Networking

### Basics of Networking

- **What is Networking**
    
    **A computer network is a digital communication network which are allowed to share resources.**
    
- **Types of Network**
    - based on Geographical Spread
        1. PAN (Personal Area Network), range of 10meters, Bluetooth/Wifi
        2. LAN (Local Area Network), range of 1-10km, Ethernet Cables, Optical
        3. MAN (Metropolitian Area Network), range of 50km, Coaxial
        4. WAN (Wide Area Network), range of 100,000km, Fiber optics
    - based on components roles
        - Client-Server Network
            
            **In the client-server model, the network architecture revolves around a central server that provides resources and services to multiple clients. This server is a powerful computer or a cluster of computers with higher processing capabilities, storage, and resources. Clients, on the other hand, are usually less powerful devices like laptops, smartphones, or desktop computers that request services or resources from the server.**
            
        - Peer-to-Peer Network
            
            **The peer-to-peer model, on the other hand, distributes the responsibilities of both client and server across all connected devices within the network. Each device in the P2P network can act as both a client and a server, allowing direct communication and resource sharing between peers without the need for a central server.**
            
- **Network Topologies**
    1. Point-to-Point
    2. The Star Topology
    3. The bus or linear Topology
    4. The Ring or circular Topology
    5. The Tree Topology
    6. Mesh Topology
    7. Fully Connected
- **Birth of Internet**
    1. **ARPA and the Birth of ARPANET (1960s-1970s)**
    The roots of the internet can be traced back to the United States Department of Defense's Advanced Research Projects Agency (ARPA, now known as DARPA). In the 1960s, ARPA was interested in developing a communication network that could withstand a nuclear attack and maintain connectivity between various research institutions and universities. This led to the creation of ARPANET, the first network to use the packet-switching technique.
    
    1. **The First Message (1969)**
    On October 29, 1969, the first message was sent over ARPANET. Charley 
    Kline, a student at UCLA, attempted to send the word "LOGIN" to the 
    Stanford Research Institute's (SRI) computer. However, the system 
    crashed after sending just the first two letters, "LO," making it the 
    first communication attempt on the internet.
    
    1. **TCP/IP Protocol (1970s)**
    The development of the Transmission Control Protocol (TCP) and Internet 
    Protocol (IP) were essential to the expansion of ARPANET. TCP/IP allowed
     different networks to communicate with each other effectively. This set
     of protocols became the foundation of the modern internet.
    
    1. **Email and DNS (1980s)**
        
        During the 1980s, several crucial developments took place. Ray Tomlinson is credited with inventing email in 1971 when he sent the first networked email. In 1983, the Domain Name System (DNS) was introduced, which allowed the mapping of domain names to numerical IP addresses, making it easier for people to access websites.
        
    2. **Commercialization and the World Wide Web (1990s)**
        
        The internet started gaining popularity beyond academic and research circles in the 1990s. The development of the World Wide Web by Tim Berners-Lee in 1989 was a significant breakthrough. It allowed information to be easily accessed and linked through web pages using HTTP (Hypertext Transfer Protocol) and HTML (Hypertext Markup Language). In 1991, the first web page was published.
        
    3. **Web Browsers and Search Engines (1990s)**
        
        The introduction of user-friendly web browsers like Mosaic (1993) and Netscape Navigator (1994) made the internet more accessible to the general public. In 1998, Google was founded, revolutionizing the way people search for information on the web.
        
    4. **Broadband and Mobile Internet (2000s)**
        
        The early 2000s saw a shift from dial-up internet to high-speed broadband connections, greatly improving internet speeds and user experiences. Additionally, the proliferation of mobile devices and advancements in mobile internet technology allowed people to access the web on the go.
        
    5. **The Internet of Things (IoT) and Cloud Computing (2010s)**
        
        The 2010s saw a rise in the Internet of Things, where various devices and objects were connected to the internet, allowing for data exchange and automation. Cloud computing also became more prevalent, enabling the storage and access of data and services over the internet.
        

### Network Devices

- **Network Devices**
    - **Server/Client**
        
        **Server - A server is a device that server service to the client** 
        
        **Client - A Client is a device that access service provided by server**
        
    - **Hub**
        
        **A hub is a simple networking device that connects multiple devices together on a single network. It does not filter or forward traffic, so all devices on the network see all traffic. Hubs are not commonly used anymore, as they have been replaced by switches.**
        
    - **Switch**
        
        **A switch is a more intelligent networking device than a hub. It filters and forwards traffic based on the destination MAC address of the packet. This allows for more efficient use of the network bandwidth. Switches are commonly used in LANs.**
        
    - **Router**
        
        **A router is a networking device that connects two or more networks together. It determines the best path for data to travel between networks based on the destination IP address of the packet. Routers are commonly used to connect LANs to WANs.**
        
    - **Repeater**
        
        **A repeater is a simple electronic device that operates at the Physical Layer (Layer 1) of the OSI (Open Systems Interconnection) model. Its primary function is to regenerate and amplify digital signals that have weakened over long transmission distances.**
        
    - **Gateway**
        
        **A gateway is a network device or software that serves as an entry or exit point between two different networks. It acts as a bridge that facilitates communication and data exchange between networks using different communication protocols or network architectures. Gateways are essential components for connecting disparate networks and enabling seamless communication between them.**
        
    - **Firewall**
        
        A hardware firewall is a physical device that is used to protect a network from unauthorized access. It does this by filtering incoming and outgoing traffic based on a set of rules. Hardware firewalls are typically more powerful and secure than software firewalls, which are installed on individual computers.
        
    - **NIC**
        
        **NIC stands for "Network Interface Card." It is a hardware component that provides the physical interface between a computer or other networked device and a local area network (LAN) or a wide area network (WAN). NICs are also known as network adapters or network cards.**
        
    - **Modem**
        
        A modem is a device that converts digital signals into analog signals and vice versa. It is used to connect computers to the internet or other networks. The name "modem" is a contraction of "modulator-demodulator."
        
        - **Modulation** is the process of converting digital
        signals into analog signals. This is done by adding a carrier signal to
        the digital signal. The carrier signal is a sine wave that is used to
        carry the digital signal over a communication channel.
        
        - **Demodulation** is the process of converting analog
        signals back into digital signals. This is done by removing the carrier
        signal from the analog signal. The digital signal is then decoded and
        processed by the computer.
    - **Bridge**
        
        **In networking, a bridge is a network device or hardware component that connects two or more separate network segments or LANs (Local Area Networks) together to form a single larger network.** 
        
        **The primary purpose of a bridge is to pass data packets between the interconnected segments efficiently, based on the MAC (Media Access Control) addresses of the devices within each segment.**
        
        **Bridges operate at the Data Link Layer (Layer 2) of the OSI (Open Systems Interconnection) model.**
        

### Interface and Cables

- Ethernet and it’s interface
    - **Types of Ethernet.**
        
        ![photo1689939302.jpeg](Networking%20ae82974675fc4269a50f21e1ea12eece/photo1689939302.jpeg)
        
    - **Receiving and Transmitting Data**
        
        ![msg963521528-27.jpg](Networking%20ae82974675fc4269a50f21e1ea12eece/msg963521528-27.jpg)
        
    - **Straight Through & Crossover Cable**
        
        **A straight-through cable, also known as a patch cable, is the most common type of Ethernet cable. In this cable, the wire arrangement at one end of the cable is exactly mirrored at the other end. This means that the wires on one end are arranged in the same order as the wires on the other end. The purpose of this cable is to connect different types of networking devices, such as a computer to a switch, router, or hub.**
        
        **A crossover cable, as the name suggests, is designed to "cross over" the transmit and receive signals between two similar devices. In this cable, the wire arrangement at one end is reversed (crossed over) at the other end. This allows two similar devices, like two computers or two switches, to communicate directly with each other without the need for an intermediate networking device like a switch or a router.**
        
    - **Concept of Auto MDI-X**
        
        **Auto MDI-X (Automatic Medium-Dependent Interface Crossover) is a feature found in modern networking equipment that automatically detects the type of Ethernet cable connected to the device's network interface (usually an Ethernet port) and configures the appropriate signaling to establish a connection. This feature eliminates the need for network administrators to worry about using the correct cable type, such as straight-through or crossover cables, when connecting devices.**
        
- Optic fiber and it’s interface
    - **Types of optical fiber**
        1. **Single-Mode Fiber (SMF): Single-mode fiber has a small core (typically 8-10 microns) and allows only one mode of light to propagate through the core. It is primarily used for long-distance communications and high-speed data transmission, such as in telecommunication networks, internet backbones, and long-haul connections.**
        2. **Multi-Mode Fiber (MMF): Multi-mode fiber has a larger core (usually 50 or 62.5 microns) that allows multiple modes of light to propagate simultaneously. MMF is commonly used for short-distance transmissions, such as within buildings, campuses, and data centers.**
            
            ![https://www.fibreoptic.com.au/wp-content/uploads/2021/02/single-mode-vs-multimode-FIBERS.jpg](https://www.fibreoptic.com.au/wp-content/uploads/2021/02/single-mode-vs-multimode-FIBERS.jpg)
            
    - **Optical fiber standards**
        
        ![photo1689935014.jpeg](Networking%20ae82974675fc4269a50f21e1ea12eece/photo1689935014.jpeg)
        
    - **Interface for optical fiber**
        
        **SC (Subscriber Connector): SC connectors are one of the most widely used connectors for single-mode and multimode fibers. They feature a square-shaped snap-in coupling mechanism, making them easy to connect and disconnect.**
        
        ![https://www.senko.com/wp-content/uploads/2021/09/Standard-Connector-231-e1660244999838.png](https://www.senko.com/wp-content/uploads/2021/09/Standard-Connector-231-e1660244999838.png)
        
        **LC (Lucent Connector): LC connectors are small, popular connectors commonly used in data centers and high-density environments. They have a push-pull mechanism and are available in simplex and duplex configurations.**
        
        ![https://s3-us-west-1.amazonaws.com/foscoshopify/graphics/uploads/2010/06/image54.png](https://s3-us-west-1.amazonaws.com/foscoshopify/graphics/uploads/2010/06/image54.png)
        
        **ST (Straight Tip): ST connectors were once widely used but are now less common. They have a bayonet-style coupling and are often used in older network installations.**
        
        ![https://intra.optokon.com/intra/product-documents/77/ST%20connector.png](https://intra.optokon.com/intra/product-documents/77/ST%20connector.png)
        
    - **SFP Transceiver**
        
        **SFP ( Small form-factor pluggable ) transceivers are commonly used in Ethernet switches, routers, and other networking devices to provide connectivity between fiber-optic or copper-based network cables and the network equipment.**
        
        ![https://m.media-amazon.com/images/I/81o8+gPLrlL.jpg](https://m.media-amazon.com/images/I/81o8+gPLrlL.jpg)
        
- Coaxial and it’s interface
    
    **Coaxial cable, often referred to as "coax," is a type of electrical cable used for transmitting high-frequency signals and data over long distances. It consists of a center conductor wire surrounded by an insulating material, which is further encased in an outer conductor shield and an outer insulating jacket.**
    
    **It is commonly used for cable television (CATV) distribution, internet access (via cable modems), CCTV (Closed-Circuit Television) systems, and some high-speed networking applications.**
    
    ![https://5.imimg.com/data5/SELLER/Default/2022/5/UP/HT/XR/313951/electrical-coaxial-cable-500x500.jpg](https://5.imimg.com/data5/SELLER/Default/2022/5/UP/HT/XR/313951/electrical-coaxial-cable-500x500.jpg)
    
    F-type connector
    
    ![https://m.media-amazon.com/images/I/61OmzsRUhQL.jpg](https://m.media-amazon.com/images/I/61OmzsRUhQL.jpg)
    

### **OSI Model**

- A Networking Models or networking protocol stack categorize and provide a structure for networking **protocols** and standards.

- **Protocols** - a set of rules defining how network devices and software should work.

- Open System Interconnection (OSI) Model Have 8 Layers that have their own protocols working own it’s layer,

- Encapsulation refers to the process of placing data from one protocol or layer into the data structure of another protocol or layer, as it travels down the protocol stack.

- Each layer in a networking protocol stack adds its own header information to the data from the layer above it, creating a hierarchical structure known as a protocol data unit (PDU).
- De-encapsulation is opposite of Encapsulation

The Green Background layers are managed by application engineers (software engineer).

The Red Background

- **Application Layer**
    - it’s topmost layer of the OSI model, it provides network services directly to end-users and applications.
    
    - Application like Firefox, email, Chore, these all application take advantage of application layer protocol like - **HTTP, FTP, TELNET, SMTP, POP3, IMAP, DNS, SNMP.**

- **Presentation Layer**
    - Data in the application layer is in “application format”, it need to be translated to different format to sent over internet
    - The Presentation layer is responsible for ensuring that data exchanged between different systems can be properly interpreted, understood, and presented to users or applications.
    - the presentation layer’s job is to translate between application and network formats.

- **Session Layer**
    - The Session layer manages the setup and teardown of communication sessions. It establishes a logical connection between two devices, allowing them to exchange data. When the communication is complete, the Session layer terminates the session, releasing any resources associated with it.
    
    - The Session layer helps control the flow of data between the sender and receiver. It ensures that data is sent and received in the correct order, preventing data loss or duplication.
    
    - if a communication session is interrupted due to a network failure or other issues, the Session layer is responsible for managing session recovery. It ensures that the session can be reestablished and that data transmission can resume without losing information.
    
    - The Session layer can handle security mechanisms such as authentication and authorization. It ensures that only authorized parties can establish sessions and access the data being exchanged.

- **Transport Layer**
    - The Transport layer breaks down larger chunks of data received from the Session layer into smaller segments for transmission.
    
    - These segments can be reassembled at the receiving end, ensuring that the data is transmitted efficiently over the network.
    
    - Two of the most well-known Transport layer protocols are TCP (Transmission Control Protocol) and UDP (User Datagram Protocol), each offering different trade-offs between reliability and efficiency.
    - A layer 4 Header added to original data, combined called **Segment**.

- **Network Layer**
    - The Network layer assigns logical addresses, often in the form of IP addresses, to devices on the network. IP addresses are hierarchical and uniquely identify each device connected to a network, allowing for global communication.
    
    - The Network layer is responsible for determining the best path for data packets to travel from the source to the destination.
    
    - Based on the destination IP address, the Network layer determines the path that data packets need to take through various networks, routers, and switches to reach the destination.
    
    - Once the path is determined, the Network layer forwards data packets to the next hop on the route. This involves encapsulating the data packet with the appropriate routing information.
    
    - two most common versions of the Internet Protocol, IPv4 and IPv6, operate at the Network layer.
    
    - A layer 3 Header added to Segment , combined called Packet

- **Data-Link Layer**
    - he Data Link layer encapsulates the data received from the Network layer into data frames that can be transmitted over the physical medium.
    
    - Frames include headers and trailers that provide information about the data, such as source and destination MAC addresses, error-checking codes, and sequence numbers.
    
    - Every network interface card (NIC) has a unique MAC address assigned to it. The Data Link layer uses MAC addresses to identify devices within the same network segment and facilitate frame delivery.
    
    - ARP is a protocol within the Data Link layer that resolves IP addresses to MAC addresses. It helps devices on the same network segment determine the MAC address of another device based on its IP address.
    - A layer 2 Header and trailer added to Packet, combined called Frame.

- **Physical Layer**
    - he Physical layer specifies the types of cables, connectors, and other transmission media used for data transfer. This includes copper cables (e.g., Ethernet cables), fiber-optic cables, and wireless channels.
    
    - The Physical layer governs the characteristics of signals, such as their voltage levels, frequencies, and modulation schemes. Proper signaling is essential to ensure that the receiver can accurately interpret the transmitted data.
    
    - The Physical layer defines the rate at which data is transmitted, measured in bits per second (bps) or other units like kilobits per second (kbps) or megabits per second (Mbps).
    

**Different Devices Works on Different Layer**

| OSI Layer | Network Devices |
| --- | --- |
| Physical | Hub, Repeater |
| Data Link | Bridge, Switch |
| Network | Router |
| Transport | Firewall |
| Application | Proxy Server, Load Balancer, Gateway, DNS Server |

### TCP/IP Model

![photo_6273574187587188752_y.jpg](Networking%20ae82974675fc4269a50f21e1ea12eece/photo_6273574187587188752_y.jpg)

### IOS CLI