# List Practical Exercise

![https://media.geeksforgeeks.org/wp-content/uploads/20210909173056/9.jpg](https://media.geeksforgeeks.org/wp-content/uploads/20210909173056/9.jpg)