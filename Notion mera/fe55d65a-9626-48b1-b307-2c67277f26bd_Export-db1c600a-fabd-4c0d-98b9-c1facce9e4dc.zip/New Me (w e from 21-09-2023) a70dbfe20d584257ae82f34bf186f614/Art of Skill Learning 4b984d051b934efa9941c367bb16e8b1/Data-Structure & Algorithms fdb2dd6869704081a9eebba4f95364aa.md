# Data-Structure & Algorithms

**Data Structures:**

1. **Arrays**
2. **Linked Lists**
3. **Stacks and Queues**
4. **Trees (Binary, AVL, Red-Black, etc.)**
5. **Hash Tables**
6. **Graphs**

**Algorithms:**

1. **Sorting algorithms (e.g. Merge Sort, Quick Sort, Heap Sort)**
2. **Searching algorithms (e.g. Binary Search)**
3. **Graph traversal algorithms (e.g. Breadth-First Search, Depth-First Search)**
4. **Dynamic Programming algorithms**
5. **Greedy algorithms**
6. **Backtracking algorithms**