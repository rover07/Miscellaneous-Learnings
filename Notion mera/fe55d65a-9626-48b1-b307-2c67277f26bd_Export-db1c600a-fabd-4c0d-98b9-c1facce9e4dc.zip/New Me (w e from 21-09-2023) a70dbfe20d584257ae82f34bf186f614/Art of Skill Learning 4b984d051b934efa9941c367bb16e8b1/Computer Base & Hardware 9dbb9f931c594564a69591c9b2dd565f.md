# Computer Base & Hardware

## Base system and electronics.

- **Number System**
    - Tally Marks
        
        **Tally marks are the oldest form of numerical notation, dating back to the Upper Paleolithic period, which is over 35,000 years ago. Tally marks are still used today in various forms, such as counting votes, keeping scores, or tracking inventory.**
        
        ![https://www.enchantedlearning.com/math/tally/tallytable2.GIF](https://www.enchantedlearning.com/math/tally/tallytable2.GIF)
        
    - Decimal Number System (Base 10)
        
        **The Decimal Number system also called the base-10 system is Composed of 10 Symbols( Deca means 10 so-called decimals), those 10 Symbols are 0,1,2,3,4,5,6,7,8,9.**
        
        **Let’s Consider 729, here 9 = unit place, 2 in tenth place, and 7 in hundreds place.**
        
        **( here 9 is LSD least significant digit and 7 is MSD Most significant Digit )**
        
        **so, 729 = (7x100)+(2x10)+(9x1)**
        
        **Let’s take = 34.56**
        
        **so, (3 x 10)+(4 x 1)+(5 x 1/10)+(6 x 1/100)**
        
        **…00000000**
        
        **…00000001**
        
        **…00000002**
        
        **…00000003**
        
        **…00000004**
        
        **…00000005**
        
        **…00000006**
        
        **…00000007**
        
        **…00000008**
        
        **…00000009**
        
        **…00000010**
        
        **…00000011**
        
        **…00000012**
        
        **…00000013**
        
        **…00000014**
        
        **…00000015**
        
        **…00000016**
        
        **…00000017**
        
        **…00000018**
        
        **…00000019**
        
    - Binary Number System (Base 2)
        
        **In a binary system, there are only two possible digits or states, 0 and 1, which can be represented using simple electronic switches. These switches can be turned on (representing 1) or off (representing 0) to store and manipulate information.**
        
        **We don’t use a decimal system in digital electronics because, in a decimal system, there are ten possible digits, 0 through 9, which would require more complex electronic components to represent and process information. This would result in increased complexity and cost, and would also be less reliable due to the higher number of possible states that could introduce errors.**
        
        **0000000 = 0**
        
        **0000001 = 1**
        
        **0000010 = 2**
        
        **0000011 = 3**
        
        **0000100 = 4**
        
        **0000101 = 5**
        
        **0000110 = 6**
        
        **0000111 = 7**
        
        **0001000 = 8**
        
        **0001001 = 9**
        
        **0001010 = 10**
        
        **0001011 = 11**
        
        **0001100 = 12**
        
        **0001101 = 13**
        
        **0001110 = 14**
        
        **0001111 = 15**
        
        **0010000 = 16**
        
        **0010001 = 17**
        
        **0010010 = 18**
        
        **0010011 = 19**
        
        **0010100 = 20**
        
    - Octal Number System (Base 8)
        
        **The octal number system is a base-8 number system. It uses eight symbols or digits, namely 0, 1, 2, 3, 4, 5, 6, and 7.**
        
        **Each digit in an octal number represents a different power of 8, starting from the rightmost digit.**
        
        T**he powers of 8 increase from right to left, with the rightmost digit representing 8^0 (which equals 1), the next digit to the left representing 8^1 (which equals 8), the next digit representing 8^2 (which equals 64)**
        
        **For example, the octal number 236 can be interpreted as:**
        
        **2 x 8^2 + 3 x 8^1 + 6 x 8^0
        = 2 x 64 + 3 x 8 + 6 x 1
        = 128 + 24 + 6
        = 158 (in decimal)**
        
    - Hexadecimal number system (Base 16)
        
        **Hexadecimal, often abbreviated as "hex", is a base-16 numbering system that uses 16 distinct symbols or digits to represent numbers. These symbols include the ten decimal digits 0-9 and six extra symbols represented by the letters A, B, C, D, E, and F. in hexadecimal notation, the digits A-F represent the values 10-15.**
        
        **Each digit in a hexadecimal number represents a different power of 16, starting from the rightmost digit. The powers of 16 increase from right to left, with the rightmost digit representing 16^0 (which equals 1), the next digit to the left representing 16^1 (which equals 16), the next digit representing 16^2 (which equals 256), and so on.**
        
        **For example, the hexadecimal number 2AF can be interpreted as:**
        
        **2 x 16^2 + 10 x 16^1 + 15 x 16^0
        = 2 x 256 + 10 x 16 + 15 x 1
        = 512 + 160 + 15
        = 687 (in decimal)**
        
    - Conversion
        - Decimal ⇋ Binary, Octal, Hexadecimal
            
            
            - Binary to Decimal
                
                To convert a binary number to a decimal number, you can use the following process:
                
                1. Start from the rightmost digit of the binary number (the least significant bit).
                2. Multiply the value of the digit (0 or 1) by 2 raised to the power of its position from the right, starting with 0 for the rightmost digit.
                3. Add up the results of these calculations for all the digits.
                
                For example, let's convert the binary number 1101 to decimal:
                
                1 * 2^0 = 1
                0 * 2^1 = 0
                1 * 2^2 = 4
                1 * 2^3 = 8
                
                Now, add these results together: 1 + 0 + 4 + 8 = 13
                
                So, the binary number 1101 is equivalent to the decimal number 13.
                
            - Decimal to Binary
                
                Converting decimal to binary involves repeatedly dividing the decimal number by 2 and recording the remainders at each step. Here's the step-by-step process:
                
                1. Start with the decimal number you want to convert to binary.
                2. Divide the decimal number by 2.
                3. Note the remainder (either 0 or 1).
                4. Divide the quotient from the previous step by 2 again.
                5. Note the remainder again.
                6. Repeat steps 4 and 5 until the quotient becomes 0.
                7. The remainders, read in reverse order, give you the binary representation.
                
                Let's go through an example. Let's convert the decimal number 37 to binary:
                
                1. 37 divided by 2 equals 18 with a remainder of 1. Write down the remainder: 1.
                2. 18 divided by 2 equals 9 with a remainder of 0. Write down the remainder: 0.
                3. 9 divided by 2 equals 4 with a remainder of 1. Write down the remainder: 1.
                4. 4 divided by 2 equals 2 with a remainder of 0. Write down the remainder: 0.
                5. 2 divided by 2 equals 1 with a remainder of 0. Write down the remainder: 0.
                6. 1 divided by 2 equals 0 with a remainder of 1. Write down the remainder: 1.
                
                Now, read the remainders in reverse order: 100101.
                
                So, the decimal number 37 is equivalent to the binary number 100101.
                
                Remember that the rightmost remainder corresponds to the least significant bit in the binary representation, and the leftmost remainder corresponds to the most significant bit.
                
            
            - Octal to decimal
                1. take a decimal number 112, reverse it 211
                2. 2 x 8^0 = 0 + 2 x 8^0 = 8 + 2 x 8^0 = 64 = 74
            - Decimal to Octal
                1. Start with the decimal number you want to convert to octal.
                2. Divide the decimal number by 8.
                3. Note the remainder (which will be in the range of 0 to 7).
                4. Repeat steps 2 and 3 until the quotient becomes 0.
                5. The remainders, read in reverse order, give you the octal representation.
                
                Let's walk through an example. Let's convert the decimal number 74 to octal:
                
                1. 74 divided by 8 equals 9 with a remainder of 2. Write down the remainder: 2.
                2. 9 divided by 8 equals 1 with a remainder of 1. Write down the remainder: 1.
                3. 1 divided by 8 equals 0 with a remainder of 1. Write down the remainder: 1.
                
                Reading the remainders in reverse order gives you 112.
                
                So, the decimal number 74 is equivalent to the octal number 112.
                
            
            - Hexadecimal to decimal
                
                Here are the hexadecimal to decimal equivalents:
                
                - A = 10
                - B = 11
                - C = 12
                - D = 13
                - E = 14
                - F = 15
                
                Let's go through an example to convert the hexadecimal number 1A3 to decimal:
                
                1 * 16^0 = 1
                A * 16^1 = 10 * 16 = 160
                3 * 16^2 = 3 * 256 = 768
                
            - Decimal to hexadecimal
                
                Converting decimal numbers to hexadecimal involves repeatedly dividing the decimal number by 16 and recording the remainders at each step. Here's the step-by-step process:
                
                1. Start with the decimal number you want to convert to hexadecimal.
                2. Divide the decimal number by 16.
                3. Note the remainder (which will be in the range of 0 to 15).
                4. Repeat steps 2 and 3 until the quotient becomes 0.
                5. The remainders, read in reverse order, give you the hexadecimal representation.
                
                In hexadecimal, after 9, the values are represented using letters: A for 10, B for 11, C for 12, D for 13, E for 14, and F for 15.
                
                Let's go through an example. Let's convert the decimal number 929 to hexadecimal:
                
                1. 929 divided by 16 equals 58 with a remainder of 1. Write down the remainder: 1.
                2. 58 divided by 16 equals 3 with a remainder of 10 (A in hexadecimal). Write down the remainder: A.
                3. 3 divided by 16 equals 0 with a remainder of 3. Write down the remainder: 3.
                
                Reading the remainders in reverse order gives you 3A1.
                
                So, the decimal number 929 is equivalent to the hexadecimal number 3A1.
                
- **Character/String Representation**
    - ASCII Code
        - ASCII stands for "American Standard Code for Information Interchange."
        
        - It is a character encoding standard that represents text, control characters, and other communication symbols as numeric values.
        
        - ASCII was developed in the 1960s and has been widely used as the foundation for encoding characters in computers and communication equipment.
        
        - In ASCII, each character is represented by a unique 7-bit binary number, which corresponds to a specific letter, digit, punctuation mark, or control character.
        
        - For example, the ASCII code for the letter 'A' is 65, 'B' is 66, 'a' is 97, '1' is 49, and so on. ASCII includes a total of 128 characters, which encompass uppercase and lowercase letters, numbers, punctuation marks, special symbols, and control codes (such as newline and tab).
        
        - While ASCII was a significant advancement for its time, it has limitations when it comes to representing characters from languages other than English and handling various special symbols. To address these limitations, other character encoding standards like Unicode were developed
    - ISCII Code
        - ISCII stands for "Indian Script Code for Information Interchange."
        - It is a character encoding standard specifically designed to represent various Indian languages and scripts on computers and communication equipment.
        - ISCII was developed to address the need for a standardized encoding system that could handle the complexities of India's diverse linguistic landscape.
    - Unicode
        - Unlike earlier character encoding standards like ASCII and ISCII, which had limitations in representing characters from various languages,
        - Unicode is designed to be comprehensive and inclusive. It covers a vast array of characters, including alphabetic scripts, ideographs, mathematical symbols, punctuation marks, diacritics, and much more.
        - Unicode assigns each character a unique code point, which is a numerical value that corresponds to that character. These code points are typically written in hexadecimal notation, such as U+0041 for the Latin capital letter 'A'.
        - Unicode is often implemented using various encoding schemes, with the most common one being UTF-8 (Unicode Transformation Format 8-bit).
        - UTF-8 uses variable-length encoding, where characters are represented using one to four bytes depending on their Unicode code point.
        - Other popular encoding schemes include UTF-16 and UTF-32.
    - UTF - 8(encoding)
        - Unicode is a standardized character set that assigns unique code points to virtually every character used in human writing systems.
        - However, directly using the full Unicode encoding for text storage and communication can be inefficient in many cases due to the large number of characters it encompasses.
        - This is where different encoding schemes, like UTF-8, come into play.
        - while Unicode is a powerful character set that can represent all the world's characters, practical considerations like backward compatibility, efficiency, and interoperability have led to the development and adoption of encoding schemes like UTF-8.
- **Transistors**
    
    ![https://c8.alamy.com/comp/2ATP7Y6/green-pcb-with-transistors-close-up-on-white-2ATP7Y6.jpg](https://c8.alamy.com/comp/2ATP7Y6/green-pcb-with-transistors-close-up-on-white-2ATP7Y6.jpg)
    
    - A transistor is a fundamental electronic component that plays a crucial role in controlling the flow of electrical current within a circuit. It is often used as an amplifier or a switch in electronic devices.
    - Transistors are key building blocks in modern electronics and have enabled the development of digital circuits, integrated circuits (ICs), and the entire field of microelectronics.
        
        **the most common type is the bipolar junction transistor (BJT) and the field-effect transistor (FET).**
        
        - **BJT (Bipoler Junction Transistor)**
            
            **Bipoler Junction Transistor**
            
            ![https://www.elprocus.com/wp-content/uploads/Bipolar-Junction-Transistor-BJT.jpg](https://www.elprocus.com/wp-content/uploads/Bipolar-Junction-Transistor-BJT.jpg)
            
            - BJT has three layers: the emitter, base, and collector.
            - There are two types of BJTs: NPN (negative-positive-negative) and PNP (positive-negative-positive).
            - The flow of current between the emitter and collector is controlled by the current flowing into the base.
            - BJTs can be used as amplifiers, switches, and signal modulators.
        - **FET (Field Effect Transistor)**
            
            ![https://www.nutsvolts.com/uploads/articles/NV_0705_Shanefield_Large.jpg](https://www.nutsvolts.com/uploads/articles/NV_0705_Shanefield_Large.jpg)
            
            - FET operates based on the voltage applied to its gate terminal, which controls the flow of current between the source and drain terminals.
            
            - There are two main types of FETs: MOSFET (Metal-Oxide-Semiconductor FET) and JFET (Junction Field-Effect Transistor).
            
            - MOSFETs are widely used in digital circuits due to their ability to provide high input impedance and low power consumption.
            
            - JFETs have voltage-controlled current flow and are used in amplifiers and low-power applications.
        
- **Capacitors**
    
    ![https://1.bp.blogspot.com/-CS-SA5f3f_U/XTmEtlYn4aI/AAAAAAAAAjk/W1X5T4sMWZAoGuNXVSNY20UfBeJqRTjtwCLcBGAs/s1600/Ceramic%2BCapacitors.jpg](https://1.bp.blogspot.com/-CS-SA5f3f_U/XTmEtlYn4aI/AAAAAAAAAjk/W1X5T4sMWZAoGuNXVSNY20UfBeJqRTjtwCLcBGAs/s1600/Ceramic%2BCapacitors.jpg)
    
    - A capacitor is another fundamental electronic component that stores and releases electrical energy.
    - It is used in various electronic circuits for purposes such as energy storage, noise filtering, coupling signals, and more.
    - Capacitors consist of two conductive plates separated by an insulating material called a dielectric. When a voltage is applied across the plates, an electric field forms between them, causing a charge to accumulate on the plates.
    - Capacitors play a crucial role in electronics by controlling the flow of AC and DC signals, filtering out noise, smoothing power supply voltages, and performing various other tasks to ensure proper circuit operation.
- **Resistors**
    
    ![https://hillmancurtis.com/wp-content/uploads/2022/10/Circuit-Board-Resistors-1-1024x753.jpg](https://hillmancurtis.com/wp-content/uploads/2022/10/Circuit-Board-Resistors-1-1024x753.jpg)
    
    - A resistor is a fundamental electronic component that restricts the flow of electric current in a circuit.
    - it is commonly used to control the amount of current flowing through a circuit, adjust voltage levels, and limit the current to prevent damage to components.
    - **Fixed Resistors:** These resistors have a specific, unchangeable resistance value. They are used in a wide range of applications, such as voltage dividers, current limiting, and signal 
    attenuation.
    - **Variable Resistors (Potentiometers and Rheostats):** These resistors allow the resistance value to be adjusted manually. Potentiometers are used to create adjustable voltage dividers, while rheostats are used to control current in a circuit.
- **Diode**
    
    ![https://5.imimg.com/data5/MW/SU/LW/SELLER-29067345/rectifier-diode-500x500.jpg](https://5.imimg.com/data5/MW/SU/LW/SELLER-29067345/rectifier-diode-500x500.jpg)
    
    - A diode is a two-terminal electronic component that allows electric current to flow in one direction while blocking it in the opposite direction.
    - It acts as a one-way valve for electric current. Diodes are essential components in electronics and are used in various applications, ranging from rectification (converting AC to DC) to signal demodulation and voltage regulation.
        1. **Rectifier Diodes:** These diodes are used for converting alternating current (AC) to direct current (DC). They allow current to flow in one direction (from anode to cathode) and block it in the reverse direction.
        
        1. **Light Emitting Diodes (LEDs):** LEDs are diodes that emit light when current flows through them. They are used for indicators, displays, lighting, and various other applications.
        
        1. **Zener Diodes:** Zener diodes are designed to operate in reverse-biased breakdown mode. They are used as voltage regulators and voltage reference sources.
        
        1. **Schottky Diodes:** Schottky diodes have a lower voltage drop and faster switching characteristics compared to standard diodes. They are often used in high-frequency applications and as rectifiers in power supply circuits.
        
        1. **Varactor Diodes (Varicap Diodes):** These diodes have a variable capacitance that changes with the applied voltage. They are used in tuning and frequency control applications.
        
        1. **Photodiodes:** Photodiodes are designed to detect light and convert it into an electric current. They are used in light-sensitive applications such as photovoltaic cells and light sensors.
        
        1. **Avalanche Diodes:** Similar to Zener diodes, avalanche diodes operate in reverse-biased breakdown mode. They are used in surge protection and high-voltage applications.
        
        1. **PIN Diodes:** These diodes have an intrinsic layer between the P-type and N-type layers, providing a larger area for the depletion region. They are used in RF and microwave applications as switches and variable resistors.

## Logic Gates

- **What is logic Gates**
    - Logic gates are fundamental building blocks of digital electronic circuits.
    - They are physical devices or components that perform logical operations on one or more binary inputs (usually 0 or 1) to produce a binary output.
- **Types of Logic Gates**
    1. AND Gate
    2. OR Gate
    3. NOT Gate(Inverter)
    4. XOR Gate(Exclusive OR)
    5. NAND Gate
    6. NOR Gate
    7. XNOR Gate
- **AND Gate**
    
    ![https://de-iitr.vlabs.ac.in/exp/truth-table-gates/images/and.png](https://de-iitr.vlabs.ac.in/exp/truth-table-gates/images/and.png)
    
    | A | B | Output |
    | --- | --- | --- |
    | 0 | 0 | 0 |
    | 0 | 1 | 0 |
    | 1 | 0 | 0 |
    | 1 | 1 | 1 |
- **OR Gate**
    
    ![https://de-iitr.vlabs.ac.in/exp/truth-table-gates/images/or.png](https://de-iitr.vlabs.ac.in/exp/truth-table-gates/images/or.png)
    
    | A | B | Output |
    | --- | --- | --- |
    | 0 | 0 | 0 |
    | 0 | 1 | 1 |
    | 1 | 0 | 1 |
    | 1 | 1 | 1 |
- **Not Gate (inverter)**
    
    ![https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Not-gate-en.svg/1200px-Not-gate-en.svg.png](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Not-gate-en.svg/1200px-Not-gate-en.svg.png)
    
    | A | Output |
    | --- | --- |
    | 0 | 1 |
    | 1 | 0 |
- **NAND Gate**
    
    ![https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Nand-gate-en.svg/1200px-Nand-gate-en.svg.png](https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Nand-gate-en.svg/1200px-Nand-gate-en.svg.png)
    
    | 0 | 0 | 1 |
    | --- | --- | --- |
    | 0 | 1 | 1 |
    | 1 | 0 | 1 |
    | 1 | 1 | 0 |
- **NOR Gate**
    
    ![https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/NOR_ANSI_Labelled.svg/1200px-NOR_ANSI_Labelled.svg.png](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/NOR_ANSI_Labelled.svg/1200px-NOR_ANSI_Labelled.svg.png)
    
    | 0 | 0 | 1 |
    | --- | --- | --- |
    | 0 | 1 | 0 |
    | 1 | 0 | 0 |
    | 1 | 1 | 0 |
- **XOR Gate(Exclusive OR)**
    
    ![https://www.computerscience.gcse.guru/wp-content/uploads/2016/11/XOR.png](https://www.computerscience.gcse.guru/wp-content/uploads/2016/11/XOR.png)
    
    | 0 | 0 | 0 |
    | --- | --- | --- |
    | 0 | 1 | 1 |
    | 1 | 0 | 1 |
    | 1 | 1 | 0 |
- **XNOR Gate**
    
    ![https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Xnor-gate-en.svg/1280px-Xnor-gate-en.svg.png](https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Xnor-gate-en.svg/1280px-Xnor-gate-en.svg.png)
    
    | A | B | Output |
    | --- | --- | --- |
    | 0 | 0 | 1 |
    | 0 | 1 | 0 |
    | 1 | 0 | 0 |
    | 1 | 1 | 1 |

## Computer Hardware.

- **Motherboard**
    
    ![https://www.computerhope.com/cdn/motherboard.jpg](https://www.computerhope.com/cdn/motherboard.jpg)
    
    - CPU Socket
        
        
        1. **PGA (Pin Grid Array): PGA processors have a grid of pins on the underside of the CPU that fit into matching holes on the motherboard's CPU socket.**
            
            ![https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Cyrix_IBM_CPU_6x86MX_PR200_bottom.jpg/220px-Cyrix_IBM_CPU_6x86MX_PR200_bottom.jpg](https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Cyrix_IBM_CPU_6x86MX_PR200_bottom.jpg/220px-Cyrix_IBM_CPU_6x86MX_PR200_bottom.jpg)
            
        2. LGA (Land Grid Array): LGA processors have an array of flat contacts on the underside of the CPU, instead of pins.
            
            ![https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Intel_CPU_Pentium_4_640_Prescott_bottom.jpg/220px-Intel_CPU_Pentium_4_640_Prescott_bottom.jpg](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Intel_CPU_Pentium_4_640_Prescott_bottom.jpg/220px-Intel_CPU_Pentium_4_640_Prescott_bottom.jpg)
            
            1. BGA (Ball Grid Array): BGA processors have solder balls on the underside of the CPU, which directly attach to pads on the motherboard. BGA CPUs are permanently soldered to the motherboard, making them non-upgradable in most cases.
            
            ![https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Solder_ball_grid.jpg/1200px-Solder_ball_grid.jpg](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Solder_ball_grid.jpg/1200px-Solder_ball_grid.jpg)
            
    - BIOS
        
        **BIOS stands for "Basic Input/Output System." It is a firmware that is embedded on a computer's motherboard and is responsible for initializing and booting the hardware components of the system when the computer is powered on.**
        
        1. Power-On Self-Test (POST): When you turn on the computer, BIOS performs a series of diagnostic tests called the POST to ensure that essential hardware components such as the CPU, RAM, storage devices, and input/output interfaces are functioning correctly.
        
        1. Bootstrap Loader: After the POST is completed, BIOS searches for the operating system's bootloader, which is typically stored on the first sector of the bootable device (such as the hard drive or SSD). The bootloader is responsible for loading the operating system into memory.
        
        1. BIOS Setup Utility: BIOS includes a configuration utility known as the BIOS Setup. Users can access this utility during the boot process (usually by pressing a specific key, such as Delete, F2, or F10) to change various hardware settings and parameters. These settings control how the computer hardware operates, and they are stored in a special memory chip called CMOS (Complementary Metal-Oxide-Semiconductor).
        
        1. CMOS: BIOS settings and configurations are stored in a small CMOS memory chip powered by a CMOS battery. This battery allows the BIOS to retain its settings even when the computer is powered off.
        
        1. UEFI Compatibility: In recent years, BIOS has been largely replaced by UEFI, which is a more modern and flexible firmware interface. UEFI offers a graphical user interface, faster boot times, support for larger disks, and improved security features.
    - CMOS Battery
        
        **the CMOS battery powers a small memory chip that stores the system's BIOS/UEFI settings, including date and time.**
        
    - RAM Slots
        
        **These slots are used to install random access memory (RAM) modules. The motherboard will support a specific type of RAM (e.g., DDR4) and have a limited number of slots.**
        
    - PCI
        
        **PCI stands for "Peripheral Component Interconnect," and it refers to a standard interface used to connect various hardware components to a computer's motherboard. The PCI standard was initially introduced in 1992 and has gone through several iterations and improvements**
        
        1. **Original PCI: The original PCI standard, often referred to as "PCI 2.3," was a 32-bit bus running at 33 MHz. It allowed for data transfer rates of up to 133 MB/s (megabytes per second) and had a maximum bandwidth of 132 MB/s due to overhead.**
        2. **PCI-X: PCI-X (PCI eXtended) was an extension of the original PCI standard. It provided higher data transfer rates and increased bandwidth by increasing the bus width and clock speed. PCI-X came in 64-bit and 32-bit variants and operated at speeds of up to 133 MHz or 66 MHz, depending on the version.**
        3. **PCI Express (PCIe): PCIe is the successor to the original PCI standard and offers significantly higher data transfer rates and improved performance. Instead of a parallel bus like PCI, PCIe uses a serial point-to-point architecture, allowing for higher speeds and scalability.**
            
            PCIe versions and their respective bandwidths at 1x link width:
            
            - PCIe 1.0/1.1: 250 MB/s (2.5 GT/s - gigatransfers per second)
            - PCIe 2.0: 500 MB/s (5 GT/s)
            - PCIe 3.0: 1 GB/s (8 GT/s)
            - PCIe 4.0: 2 GB/s (16 GT/s)
            - PCIe 5.0: 4 GB/s (32 GT/s)
            - PCIe 6.0: 8 GB/s (64 GT/s)
                
                
                **PCIe is commonly used for graphics cards, networking cards, sound cards, storage controllers, and various other expansion cards. It has become the standard for connecting high-performance components to modern motherboards.**
                
    - AGP
        
        **AGP stands for "Accelerated Graphics Port." It was a high-speed interface standard used in older computer systems to connect a dedicated graphics card to the motherboard. AGP provided a faster and more direct connection between the graphics card and the system memory compared to the traditional PCI (Peripheral Component Interconnect) slots that were commonly used for other expansion cards.**
        
        **Today, AGP has been entirely replaced by PCIe, which has continued to evolve and remains the standard interface for connecting graphics cards and other high-performance expansion cards to modern motherboards.**
        
    - Northbridge
        
        **The Northbridge was historically responsible for handling the high-speed communication between the CPU and the memory (RAM) as well as the graphics card (in systems without integrated graphics). It acted as the "bridge" between these components and the rest of the system.**
        
        **The Northbridge controlled the front side bus (FSB) or the more modern direct CPU-to-memory connection, and it also provided the interface for the AGP (Accelerated Graphics Port) or PCIe slot for the graphics card.**
        
        **In modern computer architectures, both the North Bridge and South Bridge functions have been integrated into the CPU and other components. This integration has led to more efficient and streamlined communication within the system.**
        
    - Southbridge
        
        **The Southbridge, on the other hand, handled communication between the CPU (via the Northbridge) and the slower-speed peripheral devices connected to the motherboard, such as hard drives, USB ports, audio interfaces, network interfaces, and other I/O (input/output) devices. It provided the necessary controllers and interfaces for these devices to function correctly.**
        
        **Unlike the Northbridge, the Southbridge did not require high-speed connections, as it dealt with relatively slower devices. As a result, it could be connected using a slower bus, such as the PCI bus.**
        
    - ATX Power Connector
        
        **The 24-pin ATX connector is a critical power connector used to supply power to the motherboard in modern computer systems. It is also commonly known as the "ATX power connector" or "main power connector." The 24-pin ATX connector has become the standard power connection for motherboards, replacing the older 20-pin ATX connector.**
        
    - SATA
        
        **The SATA (Serial ATA) connector is a standardized data and power interface used to connect storage devices, such as hard disk drives (HDDs), solid-state drives (SSDs), and optical drives (e.g., DVD and Blu-ray drives), to the motherboard in modern computer systems.**
        
    - Super I/O
        
        Super I/O, short for "Super Input/Output," is a type of integrated circuit (IC) commonly found on computer motherboards. It serves as a multifunctional controller that manages various input and output interfaces on the motherboard, providing essential functionality for the system's operation and interaction with external devices.
        
- **HDD**
    
    ![https://studiousguy.com/wp-content/uploads/2021/11/Components-of-a-Hard-Disk.jpg](https://studiousguy.com/wp-content/uploads/2021/11/Components-of-a-Hard-Disk.jpg)
    
    **The magnetic coating on the platter surfaces is divided into concentric circles called tracks, which are further divided into sectors.**
    
    - **Platters**
        
        **Platter - A platter, also known as a disk or a disk platter, is a key component of a hard disk drive (HDD). It is a circular, flat, rigid disk made of glass, aluminum, or other materials, coated with a magnetic material. Hard disk drives typically contain multiple platters stacked on top of each other and mounted on a spindle.**
        
        **The magnetic coating on the platter surfaces is divided into concentric circles called tracks, which are further divided into sectors.**
        
        ![https://media.geeksforgeeks.org/wp-content/uploads/harddisk1.jpg](https://media.geeksforgeeks.org/wp-content/uploads/harddisk1.jpg)
        
    - **Spindle**
        
        **The spindle in a hard disk drive (HDD) is a central component responsible for spinning the platters. It is a motorized shaft that holds and rotates the platters at high speeds.**
        
        **The motor spins the platters at a specified rotational speed, measured in revolutions per minute (RPM). Common RPM speeds for HDDs include 5,400, 7,200, and 10,000 RPM**
        
    - **Slider(head)**
        
        **The slider, also referred to as the head slider or simply the head, is a critical component in a hard disk drive (HDD). It is a small assembly that holds the read/write heads and allows them to move across the surfaces of the platters.**
        
        **The slider consists of a thin, aerodynamic body typically made of ceramic or composite materials. It is designed to fly just above the surface of the rotating platter using an air bearing created by the high-speed rotation of the platters. This microscopic gap between the slider and the platter surface is maintained by the airflow generated by the spinning motion.**
        
    - **Hard-disk PCB**
        
        **Key components and functions of the HDD PCB include:**
        
        1. **Controller Chip: The controller chip, often referred to as the HDD controller or disk controller, is the main microprocessor responsible for managing the overall operation of the hard disk drive. It handles tasks such as data access, error correction, and interface communication with the computer system.**
        2. **Motor Control: The PCB contains circuits for controlling the spindle motor, which spins the platters, as well as the actuator motor that positions the read/write heads. These circuits regulate the motor speed and positioning to ensure accurate and reliable data access.**
        3. **Interface Connectors: The PCB has connectors, such as SATA (Serial ATA) or PATA (Parallel ATA), which provide the physical interface for connecting the hard disk drive to the computer system. These connectors allow data to be transferred between the HDD and the motherboard or host controller.**
        4. **Cache Memory: Some HDD PCBs include cache memory chips that act as temporary storage for frequently accessed data. This cache helps improve overall performance by providing faster access to frequently requested information.**
        5. **Power Regulation: The PCB includes power regulation circuits that manage the supply of power to various components within the hard disk drive. These circuits ensure stable and appropriate voltage levels for proper functioning of the drive.**
    - **Inside platter**
        
        **each sector divided into three parts -** 
        
        1. **Preamble/synchronization zone** - **The preamble, also known as the synchronization zone or sync field, is a specific area at the beginning of each sector on a hard disk drive (HDD). Its primary purpose is to provide synchronization and timing information to the read/write heads during data access operations.**
            
            **When the read/write heads move across the platter surfaces, they need to precisely align with the correct position on the track to read or write data. The preamble helps achieve this synchronization by providing a unique pattern or sequence of bits that the read/write heads can detect and use as a reference point.**
            
        2. **Address - In a hard disk drive (HDD), the address in a sector refers to the unique identifier or location assigned to a specific sector on the platter surface. The address allows the read/write heads to locate and access the desired sector for data read or write operations.**
        
        1. **Data - contain user data ( typically 4kb ).**
        2. **ECC ( Error Correcting Code ) - The ECC algorithm adds extra bits to the data being stored or transmitted, creating redundancy. These extra bits contain information that enables the detection and correction of errors.**
    
- **SSD**
    - Charge Trap Flash Memory Cell (used to trap charge)
    - older technology = less charge cell = 0, more charge cell = 1
    - Newer Technology = 8 or 16 level of charge mean 3 or 4 bits
    - all this cell vertically aligned also called VNAND
    - then control GATE call the each cell through bitline
    - this vertically stack cell called A String
    - duplicate horizontally strings 32 times
    - each line horizontally called page and vertically called string and entire thing is Row
    - then we use multiple Rows
- **RAM**
    
    **RAM (Random Access Memory) is a type of volatile computer memory that provides fast and temporary storage for data that is actively being used or processed by a computer or other digital devices.**
    
    - **Dynamic RAM (DRAM)**
        
        Synchronous DRAM (SDRAM): This type of DRAM synchronizes data transfers with the computer's system clock, allowing for faster and more efficient communication between RAM and the processor.
        
        Double Data Rate Synchronous DRAM (DDR SDRAM): An improvement over SDRAM, DDR SDRAM transfers data on both the rising and falling edges of the clock signal, effectively doubling the data transfer rate compared to traditional SDRAM. There are multiple generations of DDR, such as DDR2, DDR3, DDR4, and DDR5, with each generation offering increased speed and improved efficiency.
        
    - **Static RAM (SRAM)**
        
        SRAM is faster and more reliable than DRAM. It retains data without the need for refreshing (unlike DRAM), making it suitable for cache memory and other high-performance applications.
        
    - **Flash Memory (NVRAM)**
        
        Non-Volatile RAM (NVRAM) retains data even when the power is turned off, similar to storage devices like solid-state drives (SSDs) and USB drives. It is commonly used in devices like smartphones, tablets, digital cameras, and SSDs.
        
    
    **How DRAM Works**
    
    - A DRAM Microchip
        
        contain 4 things - exterior packaging, interconnection packaging, ball grid array chip, die chip
        
    - Inside Die
        - A GB DRAM Die organized in 8 bank groups which contains 4 back each totaling 32 banks
        - each back have arrays of 65536 x 8192 cells
        - A 31-bit address use to communicate to each cell in bank
    - 31-bit Address
        
        **A 31-bit address refers to a memory address in a computer system that is represented using 31 binary digits (bits). In the context of computing and memory addressing, each memory location is assigned a unique address so that data can be accessed and manipulated by the central processing unit (CPU) or other components.**
        
        Divided into 2 parts - 21bit [RAS - Row Address Strobe], 10bit[CAS - Column Address Strobe]
        
        3bit - used to select appropriate bank group
        
        2bit - used to select bank
        
        16bit - used to determine exact row out of 65 thousand
        
        10bit - used to determine column address
        
    - How memory Cell Works
        
        called 1T1C Cell, contains two parts capacitor to store charge as data 1, 0 and transistor to read and write.
        
    
- **Processor ( CPU )**
    - **Introduction to Processors**
        - **What is Processor**
            
            **A processor, also known as a central processing unit (CPU), is the primary component of a computer or electronic device that executes instructions and performs calculations, making it the "brain" of the system.**
            
        - **Types of Socket Slot in Processors**
            - Land Grid Array
            - Ball Grid Array
            - Pin Grid Array
            - Zero Insertion Force (ZIF)
            
        - **8bit, 16bit, 32bit & 64-bit**
            
            architecture as data bus width.
            
            2^8(11111111) = 255 digits in decimal
            
            2^16 = 65,535
            
            2^32 = 4,294,967,295
            
            2^64 = 18,446,744,073,709,551,615
            
            Memory Addressing capabilities increase as we increase bit
            
        - **Clock**
            
            **The clock generates a regular electronic pulse or signal that synchronizes the operations of the CPU and other components of the computer. Each pulse of the clock signal is referred to as a "clock cycle." The clock cycle is the basic unit of time in a CPU's operation.**
            
        - **Cores**
            
            In a processor, cores refer to individual processing units that are capable of executing instructions independently. Each core essentially functions as a separate processor within a single physical chip.
            
            - **Single-Core Processors:** Traditional processors, known as single-core processors, contain only one core. They can handle one task at a time. While they are suitable for basic computing needs, they may struggle to handle demanding applications or multitasking efficiently.
            - **Multi-Core Processors:** Multi-core processors have two or more cores integrated onto a single chip. Each core can independently execute instructions, enabling the processor to work on multiple tasks simultaneously. For example, a quad-core processor has four cores, and an octa-core processor has eight cores.
            - **Parallelism:** The presence of multiple cores introduces a concept known as parallelism. This means that tasks can be divided among the cores, allowing for more efficient processing. Applications that are designed to take advantage of multiple cores can see substantial performance improvements.
        - **threads**
            
            Threads, in the context of a processor, refer to the individual paths of execution within a program. They are smaller units of tasks that can be scheduled and executed by the CPU. Threads allow a processor to handle multiple tasks concurrently, leading to improved multitasking and efficiency.
            
    - **CPU Architecture**
        
        CPU architecture refers to the design and organization of a central processing unit (CPU), including its instruction set, data pathways, memory management, and other key components. Different CPU architectures have distinct features and characteristics that influence how they process instructions and data. The architecture determines how software interacts with the hardware and how tasks are executed.
        
        - **x86_64 (64-bit x86):** This is an extension of the 
        original x86 architecture, which was widely used in personal computers. 
        "x86_64" CPUs are capable of running both 32-bit and 64-bit software. 
        The architecture supports a larger memory address space and enhanced 
        processing capabilities. Most modern PCs and servers use x86_64 CPUs. 
        Popular manufacturers for x86_64 processors include Intel and AMD.
            
            
            x86_64 = 64bit with x86 arc (developed by amd)
            
            i386 = 32bit with x86 arc The 386 in "i386" corresponds to the Intel 80386 microprocessor, which was the first processor in the x86 family to introduce a 32-bit instruction set and capabilities like protected mode and virtual memory support.
            
            i686 = 32bit with x86 arc The term "i686" refers to the 32-bit version of the x86 architecture, specifically the Intel 686 microprocessor family. It's often used to describe processors that are compatible with the 686 instruction set architecture.
            
        
        - **ARM:** ARM (Advanced RISC Machines) architecture is known
         for its energy efficiency and is commonly used in mobile devices, 
        embedded systems, and low-power applications. ARM processors are often 
        found in smartphones, tablets, IoT devices, and other portable gadgets.
        
        - **MIPS:** MIPS (Microprocessor without Interlocked Pipeline Stages) architecture is used in various applications, including networking devices, embedded systems, and some consumer electronics.
        
    - **Memory Hierarchy and Cache**
        1. **L1 Cache:**
            - Speed: Fastest access times, closely integrated with CPU cores.
            - Capacity: Smallest capacity, holds frequently used data and instructions.
            - Purpose: Provides extremely low-latency access to critical instructions and data.
            
        2. **L2 Cache:**
            - Speed: Slower than L1 cache but still faster than main memory.
            - Capacity: Larger than L1 cache, holds additional frequently accessed data.
            - Purpose: Offers a larger pool of frequently used data and helps reduce memory access latency.
            
        3. **L3 Cache:**
            - Speed: Slower than L1 and L2 caches, but faster than main memory.
            - Capacity: Largest capacity among the cache levels, shared among multiple CPU cores.
            - Purpose: Acts as a shared cache that helps reduce memory access contention and improves overall system efficiency.
- **VRM**
    
    VRM stands for Voltage Regulator Module, and it is a crucial component on a computer motherboard. The VRM is responsible for regulating and supplying the appropriate voltage to the central processing unit (CPU) or other power-hungry components on the motherboard, such as the graphics card.
    
    Modern CPUs and other components require specific voltages to operate correctly. The VRM takes the higher voltage supplied by the power supply unit (PSU) and converts it into the precise and stable voltage levels needed by the CPU. This process involves converting the voltage from a higher level (usually 12V or 5V) down to the lower voltage levels (usually around 1V) required by the CPU.
    

## Assembly Language