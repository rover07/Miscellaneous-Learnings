# Porn and MuthiBazzi

1. Porn Kya hai isse samjo, Porn matlab do log jine tum jante nhi, kabhi mile nhi, na hi kabhi miloge, unko tum sex karte huye dekh rahe ho.

1. And fhir tum uss ladke ki place me khud ko assume karte ho or muthi marte ho.

1. Ye sab cheap pleasure hai, real sex jab tume milna hoga to mil jayega uske liye tume khud ko iss competitive world me behtar banna hoga jo ki **system** tumari help karga.

1. Tume apne brain ko ye drugs de de ke uski maar li hai apna rewire karna hoga sab, rewire karne me system tumari help karega

1. Lekin kabhi kabhi ye devil tumpe havi hoga, tumko lambhi saas leni hai kam se kam 10, or fhir sochna hai tum kya karne vale ho matlab just tum abhi 2 logo ko sex karte huye dekhne wale ho ye life hai?
2. Tume sirf aaj control karna hai ye kal kaise kab tak kuch na socho bas aaj.

---